package com.spkt.app_student_attendance.view;

public interface IChangePasswordTeacherView {
    void ChangeResult(int checkresult);
}
