package com.spkt.app_student_attendance.view;

import com.spkt.app_student_attendance.model.StudentModel;

import java.util.ArrayList;

public interface IStudentListView {
    void onListClassStudentResult(ArrayList<StudentModel> List_Student);
}
