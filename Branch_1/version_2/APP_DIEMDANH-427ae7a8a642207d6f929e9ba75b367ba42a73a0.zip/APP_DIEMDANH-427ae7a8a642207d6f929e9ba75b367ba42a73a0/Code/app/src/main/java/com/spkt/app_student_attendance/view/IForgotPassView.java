package com.spkt.app_student_attendance.view;

import android.widget.EditText;

public interface IForgotPassView {
    void showPhone(String student_phone);
}
