package com.spkt.app_student_attendance.model;

public class IPConfigModel {
    private String ipconfig = "attendance1306.000webhostapp.com"; //attendance1306.000webhostapp.com
    public  IPConfigModel ()
    {
    }
    public String getIpconfig() {
        return ipconfig;
    }
}
