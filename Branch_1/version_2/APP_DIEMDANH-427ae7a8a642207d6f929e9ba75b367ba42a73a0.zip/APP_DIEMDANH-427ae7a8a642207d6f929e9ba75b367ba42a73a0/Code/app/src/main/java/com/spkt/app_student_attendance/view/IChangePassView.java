package com.spkt.app_student_attendance.view;

public interface IChangePassView {
    void updateSuccess(int checkresult);
    void responseChangePassword(String message);
}
