package com.spkt.app_student_attendance.view;

public interface IAttendanceStudentView {
    void OnCheckattendanceResult(int checkattendance);
}
