package com.spkt.app_student_attendance.view;

public interface IChangePasswordStudentView {
    void ChangeResult(int checkresult);
}
