package com.spkt.app_student_attendance.view;

public interface ILoginView {
    void onLoginResult(String role, String id_teacher, String id_student);
}