package com.spkt.app_student_attendance.presenter;

import com.spkt.app_student_attendance.view.IAttendenceTeacherView;

public interface IAttendenceTeacherPresenter {
    void doLoadListClass(String id, IAttendenceTeacherView context);
}
