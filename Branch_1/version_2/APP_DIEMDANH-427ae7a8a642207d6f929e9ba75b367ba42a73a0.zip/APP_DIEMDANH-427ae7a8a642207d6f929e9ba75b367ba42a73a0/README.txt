Phiên bản phần mềm Trial- version_demo_app
Các tính năng hiện tại của phần mềm:
- Đăng nhập phân quyền tài khoản
- Forgot Password và đổi bằng cách thông qua phương thức xác thực OTP số điện thoại
* Teacher:
- Xem thời khóa biểu cá nhân
- Xem danh sách lớp học và thông tin của từng sinh viên trong lớp học
- Xem thông tin cá nhân, cập nhật thông tin, upload hình ảnh lên hệ thống
- Điểm danh sinh viên trong lớp học ( thông qua việc xuất QR Code )
- Xem danh sách sinh viên đã điểm danh theo lớp và ngày
- Xem danh sách sinh viên đã vắng theo lớp và ngày.
*Student:
- Xem thời khóa biểu cá nhân
- Xem danh sách lớp học và thông tin của từng sinh viên trong lớp học
- Xem thông tin cá nhân, cập nhật thông tin, upload hình ảnh lên hệ thống
- Điểm danh theo môn học ( Dựa vào QR Code của giáo viên và camera của điện thoại )
- Xem lịch sử cá nhân đã điểm danh theo lớp học.
* Admin : Chờ bản cập nhật sau.

*** YÊU CẦU CẤP CÁC QUYỀN SAU ĐỂ SỬ DỤNG ỨNG DỤNG:
- Internet
- SMS
- Bộ nhớ
- Camera
- Call