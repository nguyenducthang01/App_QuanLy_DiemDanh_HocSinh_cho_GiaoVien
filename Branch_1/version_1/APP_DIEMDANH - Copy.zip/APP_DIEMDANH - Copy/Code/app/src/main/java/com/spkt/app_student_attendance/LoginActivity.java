package com.spkt.app_student_attendance;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.spkt.app_student_attendance.presenter.ILoginPresenter;
import com.spkt.app_student_attendance.presenter.LoginPresenter;
import com.spkt.app_student_attendance.view.ILoginView;
public class LoginActivity extends AppCompatActivity implements ILoginView, View.OnClickListener {
    private EditText edt_user,edt_password;
    private Button btn_login;
    private ILoginPresenter loginPresenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
        mapping();

        //Init
        loginPresenter = new LoginPresenter(this);
        //Set Listener
        btn_login.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_login) {
            String username = edt_user.getText().toString().trim();
            String password = edt_password.getText().toString().trim();
            loginPresenter.doLogin(username, password, getBaseContext());
        }
    }
    @Override
    public void onLoginResult(String role) {    // vai trò
        switch (role) {
            case "1":
                startActivity(new Intent(LoginActivity.this, AdminActivity.class));
                break;
            case "2":
                startActivity(new Intent(LoginActivity.this, TeacherActivity.class));
                break;
            case "3":
                startActivity(new Intent(LoginActivity.this, StudentActivity.class));
                break;
        }
        finish();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
    public void mapping() {
        edt_user = (EditText) findViewById(R.id.edt_username);
        edt_password = (EditText) findViewById((R.id.edt_password));
        btn_login = (Button) findViewById(R.id.btn_login);
    }


}
