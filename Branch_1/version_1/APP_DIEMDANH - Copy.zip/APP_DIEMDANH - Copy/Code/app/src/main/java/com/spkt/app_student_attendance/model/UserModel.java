package com.spkt.app_student_attendance.model;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.spkt.app_student_attendance.LoginActivity;
import com.spkt.app_student_attendance.StudentActivity;
import com.spkt.app_student_attendance.presenter.LoginPresenter;
import com.spkt.app_student_attendance.view.ILoginView;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.os.Bundle;
import android.widget.Toast;
import android.app.Activity ;

import java.io.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

//import com.spkt.app_student_attendance.StudentActivity;
//import com.vishnusivadas.advanced_httpurlconnection.FetchData;
//import com.vishnusivadas.advanced_httpurlconnection.PutData;

import org.json.JSONException;
import org.json.JSONObject;

public class UserModel extends AppCompatActivity implements IUser {
    private String username;
    private String password;
    private  String dbusername;
    private  String dbpassword;
    private String dbrole;
    private Boolean results;
    private ILoginView loginView;
    public UserModel() {
    }

    public UserModel(String username, String password, ILoginView loginView) {
        this.loginView = loginView;
        this.username = username;
        this.password = password;
    }
    @Override
    public Boolean getResults() {
        return results;
    }
    @Override
    public String getUsername() {
        return username;
    }
    @Override

    public String getPassword() {
        return password;
    }

    @Override
    public void getdata(Context context) {

    }

    @Override
    public void checkUserValidity(ILoginView context) {
//        String url = "http://192.168.1.3/student_attendence/getdata.php";
        String url = "http://192.168.1.3/getdata.php"; // Đổi IP theo XAMPP

        Map<String, String> params = new HashMap<>();
        params.put("username", username);
        params.put("password", password);

        // Tạo request với phương thức POST
        JSONObject jsonParams = new JSONObject(params);
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, jsonParams,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String status = response.getString("status");
                            if (status.equals("success")) {
                                String role = response.getString("role");
                                loginView.onLoginResult(role);
                            } else {
                                Toast.makeText(getBaseContext(), response.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Toast.makeText(getBaseContext(), "Lỗi xử lý dữ liệu!", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getBaseContext(), "Lỗi kết nối server!", Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(request);

    }

    public void setUsername(String username) {
        this.username = username;
    }
    public void setPassword(String password) {
        this.password = password;
    }
}

