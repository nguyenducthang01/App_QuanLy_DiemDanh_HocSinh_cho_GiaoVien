package com.spkt.app_student_attendance.view;

public interface ILoginView {
    void onLoginResult(String role);
}