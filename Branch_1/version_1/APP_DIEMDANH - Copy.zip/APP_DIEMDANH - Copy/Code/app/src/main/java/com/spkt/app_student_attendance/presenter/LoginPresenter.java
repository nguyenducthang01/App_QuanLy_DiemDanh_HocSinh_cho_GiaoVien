package com.spkt.app_student_attendance.presenter;

import com.spkt.app_student_attendance.model.IUser;
import com.spkt.app_student_attendance.model.UserModel;
import com.spkt.app_student_attendance.view.ILoginView;

import android.content.Context;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class LoginPresenter extends AppCompatActivity implements ILoginPresenter {
    ILoginView loginView;
    IUser userlogin;
    Handler handler;
//    private static final int REQUEST_CODE = 0x9345;
//    final Intent intent = new Intent(this, UserModel.class);
    public LoginPresenter(ILoginView iLoginView) {
        this.loginView = iLoginView;
//        handler = new Handler(Looper.getMainLooper());
    }
    private void initUser(String usern, String pass, ILoginView loginView){
        userlogin = new UserModel(usern,pass, loginView);
    }
    @Override
    public void doLogin(String user, String password, ILoginView context) {
        IUser userLogin = new UserModel(user, password, loginView);
        userLogin.checkUserValidity(context);
    }

    @Override
    public void doLogin(String user, String password, Context context) {

    }


//    @Override
//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        Toast.makeText(this, "m co vo day ko", Toast.LENGTH_LONG).show();
//        super.onActivityResult(requestCode, resultCode, data);
//        // kiểm tra
//        if (requestCode == REQUEST_CODE) {
//            // RESULT_OK chỉ ra rằng kết quả này đã thành công
//            if (resultCode == Activity.RESULT_OK) {
//                // Nhận dữ liệu từ Intent trả về
//                final String result = data.getStringExtra("key");
//                // Sử dụng kết quả result bằng cách hiện Toast
//                Toast.makeText(this, "Result: " + result, Toast.LENGTH_LONG).show();
//            } else {
//
//                // DetailActivity không thành công, không có data trả về.
//            }
//        }
//    }

}
