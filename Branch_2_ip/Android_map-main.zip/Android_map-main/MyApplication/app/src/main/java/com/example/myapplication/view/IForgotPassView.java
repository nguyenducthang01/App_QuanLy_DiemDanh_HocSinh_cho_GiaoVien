package com.example.myapplication.view;

import android.widget.EditText;

public interface IForgotPassView {
    void showPhone(String student_phone);
}
