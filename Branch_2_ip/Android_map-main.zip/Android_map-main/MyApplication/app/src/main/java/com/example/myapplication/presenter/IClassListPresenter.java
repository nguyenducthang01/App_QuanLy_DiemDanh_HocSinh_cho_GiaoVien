package com.example.myapplication.presenter;

import com.example.myapplication.view.ISClassListView;

public interface IClassListPresenter {
    void doLoadListClass(String id, ISClassListView context);

}
