package com.example.myapplication.view;

import com.example.myapplication.model.StudentModel;

import java.util.ArrayList;

public interface IStudentListView {
    void onListClassStudentResult(ArrayList<StudentModel> List_Student);
}
