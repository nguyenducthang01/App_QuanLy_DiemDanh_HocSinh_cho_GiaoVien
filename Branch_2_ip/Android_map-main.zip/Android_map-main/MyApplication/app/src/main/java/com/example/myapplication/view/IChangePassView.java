package com.example.myapplication.view;

public interface IChangePassView {
    void updateSuccess(int checkresult);
    void responseChangePassword(String message);
}
