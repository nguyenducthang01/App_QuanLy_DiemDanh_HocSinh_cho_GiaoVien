package com.example.myapplication.view;

public interface IChangePasswordTeacherView {
    void ChangeResult(int checkresult);
}
