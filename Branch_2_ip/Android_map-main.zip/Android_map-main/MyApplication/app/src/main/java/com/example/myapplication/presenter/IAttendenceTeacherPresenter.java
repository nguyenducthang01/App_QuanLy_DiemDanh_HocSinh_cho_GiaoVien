package com.example.myapplication.presenter;

import com.example.myapplication.view.IAttendenceTeacherView;

public interface IAttendenceTeacherPresenter {
    void doLoadListClass(String id, IAttendenceTeacherView context);
}
