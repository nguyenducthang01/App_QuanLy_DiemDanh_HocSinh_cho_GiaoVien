package com.example.myapplication.presenter;

import com.example.myapplication.view.IForgotPassView;

public interface IforgotPassPresenter {
    void checkUsername(String username, IForgotPassView iForgotPassView);
}
