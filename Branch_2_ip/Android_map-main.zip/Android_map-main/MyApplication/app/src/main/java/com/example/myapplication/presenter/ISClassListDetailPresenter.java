package com.example.myapplication.presenter;

import com.example.myapplication.view.ISClassListDetailView;

public interface ISClassListDetailPresenter {
    void doLoadListStudent(String id, ISClassListDetailView context);
}
