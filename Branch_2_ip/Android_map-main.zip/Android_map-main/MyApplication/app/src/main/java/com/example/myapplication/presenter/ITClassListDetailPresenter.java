package com.example.myapplication.presenter;

import com.example.myapplication.view.ITClassListDetailView;

public interface ITClassListDetailPresenter {
    void doLoadListStudent(String id, ITClassListDetailView context);
}
