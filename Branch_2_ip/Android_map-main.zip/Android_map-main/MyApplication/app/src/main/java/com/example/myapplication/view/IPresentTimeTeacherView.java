package com.example.myapplication.view;

import com.example.myapplication.model.PresentTeacherModel;

import java.util.ArrayList;

public interface IPresentTimeTeacherView {
    void onLisTimeTeacherResult(ArrayList<PresentTeacherModel> list_time);
}
