package com.example.myapplication.view;

import com.example.myapplication.model.ScheduleModel;

import java.util.ArrayList;

public interface IScheduleStudentView {
    void onListScheduleStudentResult(ArrayList<ScheduleModel> List_Schedule);
}
