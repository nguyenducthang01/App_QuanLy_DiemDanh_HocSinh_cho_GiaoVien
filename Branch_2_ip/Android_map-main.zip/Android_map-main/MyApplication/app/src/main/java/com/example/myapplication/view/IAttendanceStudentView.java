package com.example.myapplication.view;

public interface IAttendanceStudentView {
    void OnCheckattendanceResult(int checkattendance);
}
