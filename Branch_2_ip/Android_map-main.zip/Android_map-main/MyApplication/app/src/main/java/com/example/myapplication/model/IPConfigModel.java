package com.example.myapplication.model;

public class IPConfigModel {
    // private String ipconfig = "attendance1306.000webhostapp.com"; // 000webhost have shut down since October 2024 :))
    private String ipconfig = "192.168.1.101"; // Your IP
    public  IPConfigModel ()
    {
    }
    public String getIpconfig() {
        return ipconfig;
    }
}
