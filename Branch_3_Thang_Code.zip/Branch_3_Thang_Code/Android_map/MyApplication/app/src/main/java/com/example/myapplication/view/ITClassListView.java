package com.example.myapplication.view;

import com.example.myapplication.model.ClassModel;

import java.util.ArrayList;

public interface ITClassListView {
    void onListClassTeacherResult(ArrayList<ClassModel> List_Class);
}
