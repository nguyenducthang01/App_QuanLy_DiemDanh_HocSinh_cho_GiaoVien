package com.example.myapplication.view;

import com.example.myapplication.model.ClassModel;

import java.util.ArrayList;

public interface IPresentStudentView {
    void onListClassStudentResult(ArrayList<ClassModel> List_Class);
}
