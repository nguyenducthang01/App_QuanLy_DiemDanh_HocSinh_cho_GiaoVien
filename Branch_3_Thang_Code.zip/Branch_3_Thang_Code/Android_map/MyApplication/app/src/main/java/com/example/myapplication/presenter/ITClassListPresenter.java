package com.example.myapplication.presenter;


import com.example.myapplication.view.ITClassListView;

public interface ITClassListPresenter {
    void doLoadListTeacher(String id, ITClassListView context);
}
