//package com.example.myapplication.Ultils;
//
//import android.util.Log;
//
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.Properties;
//
//import javax.mail.Authenticator;
//import javax.mail.Message;
//import javax.mail.PasswordAuthentication;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeMessage;
//
//public class SendToEmail {
//    //  Hàm gửi Email tới người dùng
//    public void guiEmail(String name, String email) {
//        try {
//            Date now = new Date();
//            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
//            String formattedDate = formatter.format(now);
//            //
//            TaiKhoan tk = taiKhoan_User;
//            String fromEmail = "nguyenducthang23052004tb@gmail.com";    // Chuyển Email sang chế độ xác thực 2 bước
//            String emailPassword = "guuwfnsomqpkfcbz";                  // Mật khẩu ứng dụng
//            // Địa chỉ email người nhận
//            String toEmail = tk.getEmail();
//            // Tiêu đề thư
//            String subject = "Hệ thống quản lý sách gửi Email thông báo tới người dùng "
//                    + tk.getHo_ten()
//                    + " thành công !!!";
//            // Nội dung thư
//            String content1 = "Hệ thống quản lý sách thông báo người dùng "
//                    + tk.getHo_ten()
//                    + " đã dăng ký tài khoản mới thành công !!! \n"
//                    + "Chào mừng bạn đến với hệ thống tiện ích của chúng tôi.\n"
//                    + "Chúng tôi luôn sẵn sàng phục vụ bạn.\n"
//                    + "Cảm ơn vì bạn đã tin tưởng và sử dụng hệ thống quản lý sách của nhóm 9 chúng tôi !!!\n"
//                    + "THANK YOU SO MUCH! ! !";
//            String content2 = "Hệ thống quản lý sách thông báo người dùng "
//                    + tk.getHo_ten()
//                    + " đã đăng nhập vào tài khoản !!! \n"
//                    + "Xin Chào _ " + tk.getHo_ten() + " _\n"
//                    + "Bạn đã đăng nhập vào lúc " + formattedDate + " \n"
//                    + "Cảm ơn vì bạn đã tin tưởng và sử dụng hệ thống quản lý sách của nhóm 9 chúng tôi !!! \n"
//                    + "THANK YOU SO MUCH! ! !";
//            String content3 = "Hệ thống quản lý sách thông báo người dùng "
//                    + tk.getHo_ten()
//                    + " đã đổi mật khẩu thành công !!! \n"
//                    + "Mật khẩu mới của bạn là '"
//                    + tk.getMat_khau() + "'\n"
//                    + "Cảm ơn vì bạn đã tin tưởng và sử dụng hệ thống quản lý sách của nhóm 9 chúng tôi !!! \n"
//                    + "THANK YOU SO MUCH! ! !";
//            String content = "";
//            if (n == 1){ content = content1; }          // Đăng ký
//            else if (n == 2){ content = content2; }     // Đăng nhập
//            else if (n == 3){ content = content3; }     // Đổi mật khẩu
//            //  Cài đặt thông tin email
//            String host = "smtp.gmail.com";
//            Properties properties = System.getProperties();
//            properties.put("mail.smtp.host", host);
//            properties.put("mail.smtp.port", "465");
//            properties.put("mail.smtp.ssl.enable", "true");
//            properties.put("mail.smtp.auth", "true");
//            //
//            Session session =Session.getInstance(properties, new Authenticator() {
//                @Override
//                protected PasswordAuthentication getPasswordAuthentication() {
//                    return new PasswordAuthentication(fromEmail, emailPassword);
//                }
//            });
//            //
//            MimeMessage mimeMessage = new MimeMessage(session);
//            mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
//            mimeMessage.setSubject(subject);
//            mimeMessage.setText(content);
//            //
//            Thread emailThread = new Thread(new Runnable() {
//                @Override
//                public void run() {
//                    try {
//                        Transport.send(mimeMessage);
//                        Log.d("Lỗi Gửi email", "Email gửi thành công!");
//                    } catch (Exception e) {
//                        Log.d("Lỗi Thread Email", e.toString());
//                    }
//                }
//            });
//            emailThread.start();
//        } catch (Exception e) {
//            Log.d("Lỗi gửi Email","Lỗi gửi Email tới người dùng: "+e.toString());
//        }
//    }
//}
