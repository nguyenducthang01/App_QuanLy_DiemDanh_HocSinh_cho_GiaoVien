package com.example.myapplication.presenter;

import com.example.myapplication.view.ITScheduleTeacherView;

public interface ITScheduleTeacherPresenter {
    void doLoadListSchedule(String id, ITScheduleTeacherView context);
}
