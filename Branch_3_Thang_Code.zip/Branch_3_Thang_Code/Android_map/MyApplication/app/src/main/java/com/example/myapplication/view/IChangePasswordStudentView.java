package com.example.myapplication.view;

public interface IChangePasswordStudentView {
    void ChangeResult(int checkresult);
}
